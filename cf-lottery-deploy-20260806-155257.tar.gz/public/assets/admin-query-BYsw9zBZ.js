function a(t,i,s){const o=Number.isFinite(t)&&t>0?Math.floor(t):1,n=Number.isFinite(i)&&i>0?Math.floor(i):20;return{limit:String(n),offset:String((o-1)*n)}}export{a as b};
